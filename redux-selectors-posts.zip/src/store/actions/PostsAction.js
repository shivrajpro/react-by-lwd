export const INCREMENT_COUNT = '[counter] increment';

export const incrementCount = () => {
    return {
        type: INCREMENT_COUNT
    }
}