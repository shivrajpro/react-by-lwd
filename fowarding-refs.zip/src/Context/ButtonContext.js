import React from 'react';

const ButtonContext = React.createContext();

export default ButtonContext;
