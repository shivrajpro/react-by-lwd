import './App.css';

function App() {
    return (
        <div className='p-2 border border-gray-500 container mx-auto'>
            <p>app works!</p>
            <button className='bg-red-500 px-3 py-1 text-white' >increment</button>
        </div>
    );
}

export default App;
