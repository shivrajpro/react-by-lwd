import './App.css';

function App() {
    return (
        <div className='container mx-auto'>
            <h2>app works!</h2>
        </div>
    );
}

export default App;
