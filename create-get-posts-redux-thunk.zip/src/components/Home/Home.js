export default function Home() {
    return (
        <div className="p-2">
            <p>home works!</p>
        </div>
    )
}