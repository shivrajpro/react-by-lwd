import { applyMiddleware, createStore } from "redux";
import PostsReducer from "./reducers/PostsReducer";

// const exampleMiddleware = store => next => action => next(action)
const loggerMiddleware = store => next => action => {
    console.log('dispatching action',action);
    console.log('STATE BEFORE dispatching',store.getState());
    let result = next(action);
    console.log('STATE AFTER dispatching',store.getState());
    return result;

}
const middleware = applyMiddleware(loggerMiddleware);

export const store = createStore(PostsReducer, middleware);


/* 
function exampleMiddleWare(store) {
    return function (next) {
        return function (action) {
            return next(action);
        }
    }
}
*/