import './App.css';
import Posts from './components/Posts/Posts';

function App() {
    return (
        <div className='container mx-auto px-2 py-2'>
            <Posts />
        </div>
    );
}

export default App;